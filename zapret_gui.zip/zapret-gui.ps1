﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ── Встроенные C#-классы для MD3-элементов ───────────────────────────────────
Add-Type @"
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

public class MD3Panel : Panel {
    private int _radius = 16;
    public int Radius { get { return _radius; } set { _radius = value; Invalidate(); } }

    public MD3Panel() {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        DoubleBuffered = true;
    }

    protected override void OnPaint(PaintEventArgs e) {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using (GraphicsPath path = RoundRect(ClientRectangle, _radius))
        using (SolidBrush b = new SolidBrush(BackColor)) {
            e.Graphics.FillPath(b, path);
            Region = new Region(path);
        }
    }

    public static GraphicsPath RoundRect(Rectangle r, int rad) {
        int d = rad * 2;
        GraphicsPath p = new GraphicsPath();
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }
}

public class MD3Button : Button {
    private int _radius = 20;
    private Color _hoverColor;
    private Color _pressColor;
    private bool _hover = false;
    private bool _pressed = false;

    public int Radius { get { return _radius; } set { _radius = value; Invalidate(); } }
    public Color HoverColor { get { return _hoverColor; } set { _hoverColor = value; } }
    public Color PressColor { get { return _pressColor; } set { _pressColor = value; } }

    public MD3Button() {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer, true);
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        Cursor = Cursors.Hand;
    }

    protected override void OnMouseEnter(EventArgs e) { _hover = true;  Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { _hover = false; _pressed = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { _pressed = true;  Invalidate(); base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e)   { _pressed = false; Invalidate(); base.OnMouseUp(e); }

    protected override void OnPaint(PaintEventArgs e) {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

        Color bg = BackColor;
        if (_pressed && _pressColor != Color.Empty) bg = _pressColor;
        else if (_hover && _hoverColor != Color.Empty) bg = _hoverColor;

        using (GraphicsPath path = MD3Panel.RoundRect(ClientRectangle, _radius))
        using (SolidBrush b = new SolidBrush(bg)) {
            e.Graphics.FillPath(b, path);
            Region = new Region(path);
        }

        StringFormat sf = new StringFormat {
            Alignment = StringAlignment.Center,
            LineAlignment = StringAlignment.Center
        };
        using (SolidBrush tb = new SolidBrush(ForeColor)) {
            e.Graphics.DrawString(Text, Font, tb, ClientRectangle, sf);
        }
    }
}

public class MD3ComboBox : ComboBox {
    public MD3ComboBox() {
        DrawMode = DrawMode.OwnerDrawFixed;
        DropDownStyle = ComboBoxStyle.DropDownList;
        FlatStyle = FlatStyle.Flat;
        ItemHeight = 28;
    }
    protected override void OnDrawItem(DrawItemEventArgs e) {
        if (e.Index < 0) return;
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        bool selected = (e.State & DrawItemState.Selected) != 0;
        Color bg = selected ? Color.FromArgb(79, 55, 139) : Color.FromArgb(30, 27, 38);
        e.Graphics.FillRectangle(new SolidBrush(bg), e.Bounds);
        e.Graphics.DrawString(Items[e.Index].ToString(), e.Font ?? Font,
            new SolidBrush(Color.FromArgb(230, 225, 229)),
            e.Bounds.X + 10, e.Bounds.Y + 5);
    }
}
"@ -ReferencedAssemblies System.Windows.Forms, System.Drawing

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# ── Режимы ───────────────────────────────────────────────────────────────────
$modes = @(
    [PSCustomObject]@{ Name = "general";             File = "general.bat";                      Desc = "Стандартный режим. Рекомендуется попробовать первым." },
    [PSCustomObject]@{ Name = "ALT";                 File = "general (ALT).bat";                Desc = "Альтернативный метод 1. Если general не помог." },
    [PSCustomObject]@{ Name = "ALT 2";               File = "general (ALT2).bat";               Desc = "Альтернативный метод 2." },
    [PSCustomObject]@{ Name = "ALT 3";               File = "general (ALT3).bat";               Desc = "Альтернативный метод 3." },
    [PSCustomObject]@{ Name = "ALT 4";               File = "general (ALT4).bat";               Desc = "Альтернативный метод 4." },
    [PSCustomObject]@{ Name = "ALT 5";               File = "general (ALT5).bat";               Desc = "Альтернативный метод 5." },
    [PSCustomObject]@{ Name = "ALT 6";               File = "general (ALT6).bat";               Desc = "Альтернативный метод 6." },
    [PSCustomObject]@{ Name = "ALT 7";               File = "general (ALT7).bat";               Desc = "Альтернативный метод 7." },
    [PSCustomObject]@{ Name = "ALT 8";               File = "general (ALT8).bat";               Desc = "Альтернативный метод 8." },
    [PSCustomObject]@{ Name = "ALT 9";               File = "general (ALT9).bat";               Desc = "Альтернативный метод 9." },
    [PSCustomObject]@{ Name = "ALT 10";              File = "general (ALT10).bat";              Desc = "Альтернативный метод 10." },
    [PSCustomObject]@{ Name = "ALT 11";              File = "general (ALT11).bat";              Desc = "Альтернативный метод 11. Самый агрессивный из ALT." },
    [PSCustomObject]@{ Name = "FAKE TLS AUTO";       File = "general (FAKE TLS AUTO).bat";      Desc = "Авто Fake TLS. Хорошо работает на многих провайдерах." },
    [PSCustomObject]@{ Name = "FAKE TLS AUTO ALT";   File = "general (FAKE TLS AUTO ALT).bat";  Desc = "Fake TLS AUTO — альтернативный вариант 1." },
    [PSCustomObject]@{ Name = "FAKE TLS AUTO ALT 2"; File = "general (FAKE TLS AUTO ALT2).bat"; Desc = "Fake TLS AUTO — альтернативный вариант 2." },
    [PSCustomObject]@{ Name = "FAKE TLS AUTO ALT 3"; File = "general (FAKE TLS AUTO ALT3).bat"; Desc = "Fake TLS AUTO — альтернативный вариант 3." },
    [PSCustomObject]@{ Name = "SIMPLE FAKE";         File = "general (SIMPLE FAKE).bat";        Desc = "Простой Fake-режим. Лёгкий и быстрый." },
    [PSCustomObject]@{ Name = "SIMPLE FAKE ALT";     File = "general (SIMPLE FAKE ALT).bat";    Desc = "Простой Fake — альтернативный вариант 1." },
    [PSCustomObject]@{ Name = "SIMPLE FAKE ALT 2";   File = "general (SIMPLE FAKE ALT2).bat";   Desc = "Простой Fake — альтернативный вариант 2." }
)

# ── MD3 Dark цветовые токены (Purple seed) ───────────────────────────────────
$clrBackground   = [System.Drawing.Color]::FromArgb(20, 18, 24)
$clrSurface      = [System.Drawing.Color]::FromArgb(28, 27, 31)
$clrSurfaceHigh  = [System.Drawing.Color]::FromArgb(43, 41, 48)
$clrSurfaceVar   = [System.Drawing.Color]::FromArgb(36, 33, 44)
$clrPrimary      = [System.Drawing.Color]::FromArgb(208, 188, 255)   # #D0BCFF
$clrOnPrimary    = [System.Drawing.Color]::FromArgb(56, 30, 114)     # #381E72
$clrPrimaryCtrl  = [System.Drawing.Color]::FromArgb(79, 55, 139)     # #4F378B
$clrSecondary    = [System.Drawing.Color]::FromArgb(204, 194, 220)
$clrError        = [System.Drawing.Color]::FromArgb(242, 184, 181)
$clrOnError      = [System.Drawing.Color]::FromArgb(96, 20, 16)
$clrErrorCtrl    = [System.Drawing.Color]::FromArgb(140, 29, 24)
$clrOnSurface    = [System.Drawing.Color]::FromArgb(230, 225, 229)
$clrOnSurfaceVar = [System.Drawing.Color]::FromArgb(202, 196, 208)
$clrOutline      = [System.Drawing.Color]::FromArgb(147, 143, 153)
$clrGreen        = [System.Drawing.Color]::FromArgb(102, 212, 161)

# ── Шрифты ───────────────────────────────────────────────────────────────────
$fDisplay = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Regular)
$fTitle   = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Regular)
$fBody    = New-Object System.Drawing.Font("Segoe UI", 9)
$fLabel   = New-Object System.Drawing.Font("Segoe UI", 8)
$fBtn     = New-Object System.Drawing.Font("Segoe UI", 9,  [System.Drawing.FontStyle]::Bold)
$fLog     = New-Object System.Drawing.Font("Consolas", 8.5)

# ── Форма ────────────────────────────────────────────────────────────────────
$form = New-Object System.Windows.Forms.Form
$form.Text            = "Zapret"
$form.Size            = New-Object System.Drawing.Size(560, 620)
$form.MinimumSize     = $form.Size
$form.MaximumSize     = $form.Size
$form.StartPosition   = "CenterScreen"
$form.BackColor       = $clrBackground
$form.ForeColor       = $clrOnSurface
$form.FormBorderStyle = "Sizable"
$form.MaximizeBox     = $false
$form.Icon            = [System.Drawing.SystemIcons]::Shield

# ════════════════════════════════════════════════════════════════════════════
# TOP BAR
# ════════════════════════════════════════════════════════════════════════════
$topBar = New-Object System.Windows.Forms.Panel
$topBar.BackColor = $clrSurfaceHigh
$topBar.Location  = New-Object System.Drawing.Point(0, 0)
$topBar.Size      = New-Object System.Drawing.Size(560, 72)
$form.Controls.Add($topBar)

$lblHeadline = New-Object System.Windows.Forms.Label
$lblHeadline.Text      = "Zapret"
$lblHeadline.Font      = $fDisplay
$lblHeadline.ForeColor = $clrPrimary
$lblHeadline.Location  = New-Object System.Drawing.Point(24, 10)
$lblHeadline.Size      = New-Object System.Drawing.Size(300, 28)
$topBar.Controls.Add($lblHeadline)

$lblSub = New-Object System.Windows.Forms.Label
$lblSub.Text      = "Обход блокировок Discord и YouTube"
$lblSub.Font      = $fLabel
$lblSub.ForeColor = $clrOnSurfaceVar
$lblSub.Location  = New-Object System.Drawing.Point(26, 40)
$lblSub.Size      = New-Object System.Drawing.Size(400, 18)
$topBar.Controls.Add($lblSub)

# ════════════════════════════════════════════════════════════════════════════
# КАРТОЧКА: РЕЖИМ
# ════════════════════════════════════════════════════════════════════════════
$cardMode = New-Object MD3Panel
$cardMode.BackColor = $clrSurface
$cardMode.Radius    = 16
$cardMode.Location  = New-Object System.Drawing.Point(20, 88)
$cardMode.Size      = New-Object System.Drawing.Size(516, 118)
$form.Controls.Add($cardMode)

$lblModeHead = New-Object System.Windows.Forms.Label
$lblModeHead.Text      = "Режим обхода"
$lblModeHead.Font      = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Bold)
$lblModeHead.ForeColor = $clrPrimary
$lblModeHead.Location  = New-Object System.Drawing.Point(16, 12)
$lblModeHead.Size      = New-Object System.Drawing.Size(480, 16)
$cardMode.Controls.Add($lblModeHead)

$combo = New-Object MD3ComboBox
$combo.Font        = $fBody
$combo.BackColor   = [System.Drawing.Color]::FromArgb(30, 27, 38)
$combo.ForeColor   = $clrOnSurface
$combo.Location    = New-Object System.Drawing.Point(16, 34)
$combo.Size        = New-Object System.Drawing.Size(484, 30)
foreach ($m in $modes) { $combo.Items.Add($m.Name) | Out-Null }
$combo.SelectedIndex = 0
$cardMode.Controls.Add($combo)

$lblDesc = New-Object System.Windows.Forms.Label
$lblDesc.Font      = $fLabel
$lblDesc.ForeColor = $clrOnSurfaceVar
$lblDesc.Location  = New-Object System.Drawing.Point(16, 72)
$lblDesc.Size      = New-Object System.Drawing.Size(484, 36)
$lblDesc.Text      = $modes[0].Desc
$cardMode.Controls.Add($lblDesc)

$combo.Add_SelectedIndexChanged({ $lblDesc.Text = $modes[$combo.SelectedIndex].Desc })

# ════════════════════════════════════════════════════════════════════════════
# КАРТОЧКА: СТАТУС
# ════════════════════════════════════════════════════════════════════════════
$cardStatus = New-Object MD3Panel
$cardStatus.BackColor = $clrSurface
$cardStatus.Radius    = 16
$cardStatus.Location  = New-Object System.Drawing.Point(20, 220)
$cardStatus.Size      = New-Object System.Drawing.Size(516, 66)
$form.Controls.Add($cardStatus)

$lblStatusHead = New-Object System.Windows.Forms.Label
$lblStatusHead.Text      = "Статус"
$lblStatusHead.Font      = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Bold)
$lblStatusHead.ForeColor = $clrPrimary
$lblStatusHead.Location  = New-Object System.Drawing.Point(16, 10)
$lblStatusHead.Size      = New-Object System.Drawing.Size(200, 16)
$cardStatus.Controls.Add($lblStatusHead)

# Точка-индикатор
$dot = New-Object System.Windows.Forms.Panel
$dot.Size      = New-Object System.Drawing.Size(10, 10)
$dot.Location  = New-Object System.Drawing.Point(16, 38)
$dot.BackColor = $clrError
# Сделать круглым
$dot.Add_Paint({
    param($s, $e)
    $e.Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $e.Graphics.FillEllipse((New-Object System.Drawing.SolidBrush($dot.BackColor)),
        0, 0, $dot.Width - 1, $dot.Height - 1)
})
$dot.BackColor = [System.Drawing.Color]::Transparent
$cardStatus.Controls.Add($dot)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text      = "Остановлен"
$lblStatus.Font      = $fBody
$lblStatus.ForeColor = $clrError
$lblStatus.Location  = New-Object System.Drawing.Point(32, 33)
$lblStatus.Size      = New-Object System.Drawing.Size(460, 20)
$cardStatus.Controls.Add($lblStatus)

# ════════════════════════════════════════════════════════════════════════════
# КНОПКИ (MD3 Filled + Tonal)
# ════════════════════════════════════════════════════════════════════════════
$btnStart = New-Object MD3Button
$btnStart.Text       = "Запустить"
$btnStart.Font       = $fBtn
$btnStart.BackColor  = $clrPrimaryCtrl
$btnStart.ForeColor  = $clrOnSurface
$btnStart.HoverColor = [System.Drawing.Color]::FromArgb(98, 70, 155)
$btnStart.PressColor = [System.Drawing.Color]::FromArgb(60, 42, 110)
$btnStart.Radius     = 20
$btnStart.Location   = New-Object System.Drawing.Point(20, 302)
$btnStart.Size       = New-Object System.Drawing.Size(248, 44)
$form.Controls.Add($btnStart)

$btnStop = New-Object MD3Button
$btnStop.Text        = "Остановить"
$btnStop.Font        = $fBtn
$btnStop.BackColor   = $clrErrorCtrl
$btnStop.ForeColor   = $clrOnSurface
$btnStop.HoverColor  = [System.Drawing.Color]::FromArgb(165, 40, 34)
$btnStop.PressColor  = [System.Drawing.Color]::FromArgb(110, 22, 18)
$btnStop.Radius      = 20
$btnStop.Location    = New-Object System.Drawing.Point(288, 302)
$btnStop.Size        = New-Object System.Drawing.Size(248, 44)
$btnStop.Enabled     = $false
$form.Controls.Add($btnStop)

# ════════════════════════════════════════════════════════════════════════════
# КАРТОЧКА: ЛОГ
# ════════════════════════════════════════════════════════════════════════════
$cardLog = New-Object MD3Panel
$cardLog.BackColor = $clrSurface
$cardLog.Radius    = 16
$cardLog.Location  = New-Object System.Drawing.Point(20, 362)
$cardLog.Size      = New-Object System.Drawing.Size(516, 208)
$form.Controls.Add($cardLog)

$lblLogHead = New-Object System.Windows.Forms.Label
$lblLogHead.Text      = "Лог"
$lblLogHead.Font      = New-Object System.Drawing.Font("Segoe UI", 8, [System.Drawing.FontStyle]::Bold)
$lblLogHead.ForeColor = $clrPrimary
$lblLogHead.Location  = New-Object System.Drawing.Point(16, 10)
$lblLogHead.Size      = New-Object System.Drawing.Size(200, 16)
$cardLog.Controls.Add($lblLogHead)

$txtLog = New-Object System.Windows.Forms.RichTextBox
$txtLog.BackColor   = $clrSurface
$txtLog.ForeColor   = $clrOnSurface
$txtLog.Font        = $fLog
$txtLog.ReadOnly    = $true
$txtLog.ScrollBars  = "Vertical"
$txtLog.BorderStyle = "None"
$txtLog.Location    = New-Object System.Drawing.Point(14, 30)
$txtLog.Size        = New-Object System.Drawing.Size(488, 168)
$cardLog.Controls.Add($txtLog)

# ════════════════════════════════════════════════════════════════════════════
# ЛОГИКА
# ════════════════════════════════════════════════════════════════════════════
$dotGreen  = $clrGreen
$dotRed    = [System.Drawing.Color]::FromArgb(242, 184, 181)

function Write-Log($msg, $color = $null) {
    $time = (Get-Date).ToString("HH:mm:ss")
    $txtLog.SelectionStart  = $txtLog.TextLength
    $txtLog.SelectionLength = 0
    $txtLog.SelectionColor  = if ($color) { $color } else { $clrOnSurface }
    $txtLog.AppendText("[$time]  $msg`n")
    $txtLog.ScrollToCaret()
}

function Get-WinwsProcess { Get-Process -Name "winws" -ErrorAction SilentlyContinue }

function Update-Status {
    $running = $null -ne (Get-WinwsProcess)
    if ($running) {
        $dot.BackColor       = $dotGreen
        $dot.Invalidate()
        $lblStatus.Text      = "Запущен"
        $lblStatus.ForeColor = $dotGreen
        $btnStart.Enabled    = $false
        $btnStop.Enabled     = $true
        $combo.Enabled       = $false
    } else {
        $dot.BackColor       = $dotRed
        $dot.Invalidate()
        $lblStatus.Text      = "Остановлен"
        $lblStatus.ForeColor = $dotRed
        $btnStart.Enabled    = $true
        $btnStop.Enabled     = $false
        $combo.Enabled       = $true
    }
}

# Таймер статуса
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.Add_Tick({ Update-Status })
$timer.Start()

# Кнопка ЗАПУСТИТЬ
$btnStart.Add_Click({
    $mode    = $modes[$combo.SelectedIndex]
    $batPath = Join-Path $scriptDir $mode.File
    if (-not (Test-Path $batPath)) {
        Write-Log "Файл не найден: $($mode.File)" $clrError
        return
    }
    Write-Log "Запуск режима: $($mode.Name)..." $clrPrimary
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName         = "cmd.exe"
    $psi.Arguments        = "/c `"$batPath`""
    $psi.WorkingDirectory = $scriptDir
    $psi.Verb             = "runas"
    $psi.WindowStyle      = "Hidden"
    $psi.UseShellExecute  = $true
    try {
        [System.Diagnostics.Process]::Start($psi) | Out-Null
        Start-Sleep -Milliseconds 1800
        Update-Status
        if ($null -ne (Get-WinwsProcess)) {
            Write-Log "Успешно запущен!" $clrGreen
        } else {
            Write-Log "Запущен, ожидание инициализации..." $clrOnSurfaceVar
        }
    } catch {
        Write-Log "Ошибка: $_" $clrError
    }
})

# Кнопка ОСТАНОВИТЬ
$btnStop.Add_Click({
    Write-Log "Остановка winws.exe..." $clrOnSurfaceVar
    try {
        if (Get-WinwsProcess) {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName        = "taskkill"
            $psi.Arguments       = "/F /IM winws.exe"
            $psi.Verb            = "runas"
            $psi.WindowStyle     = "Hidden"
            $psi.UseShellExecute = $true
            [System.Diagnostics.Process]::Start($psi) | Out-Null
            Start-Sleep -Milliseconds 800
            Update-Status
            Write-Log "Остановлен." $clrGreen
        } else {
            Write-Log "winws.exe не запущен." $clrOnSurfaceVar
            Update-Status
        }
    } catch {
        Write-Log "Ошибка остановки: $_" $clrError
    }
})

# Стартовое сообщение после показа формы
$form.Add_Shown({
    Write-Log "Готов. Выбери режим и нажми Запустить." $clrPrimary
    Update-Status
})

[System.Windows.Forms.Application]::Run($form)

