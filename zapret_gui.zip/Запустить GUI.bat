@echo off
cd /d "%~dp0gui"

if not exist "node_modules\electron" (
    echo Installing Electron, please wait...
    npm install
    if %errorlevel% neq 0 (
        echo ERROR: npm install failed!
        pause
        exit /b 1
    )
)

start "" node_modules\.bin\electron.cmd .