const { app, BrowserWindow, ipcMain, shell, Menu, Tray, nativeImage } = require('electron')
const path = require('path')
const os   = require('os')
const { execSync, spawn } = require('child_process')

// Указываем папку для данных Electron в AppData — без этого кэш падает с ошибкой 0x5
app.setPath('userData', path.join(os.homedir(), 'AppData', 'Roaming', 'zapret-gui'))

const BAT_DIR = path.join(__dirname, '..')

let win  = null
let tray = null
let lastStatus = null

// ── Создание окна ────────────────────────────────────────────────────────────
function createWindow () {
  win = new BrowserWindow({
    width:     940,
    height:    660,
    minWidth:  940,
    minHeight: 660,
    frame:     false,
    show:      false,
    backgroundColor: '#141218',
    webPreferences: {
      preload:          path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration:  false,
    }
  })

  win.loadFile(path.join(__dirname, 'app.html'))
  win.once('ready-to-show', () => win.show())
  win.on('close', e => { e.preventDefault(); win.hide() })
}

// ── Трей ─────────────────────────────────────────────────────────────────────
function createTray () {
  try {
    tray = new Tray(nativeImage.createEmpty())
    tray.setToolTip('Zapret — Обход блокировок')
    tray.on('click', () => { win.show(); win.focus() })
    updateTrayMenu()
  } catch {}
}

function updateTrayMenu () {
  if (!tray) return
  const running = isRunning()
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: running ? '● Запущен' : '○ Остановлен', enabled: false },
    { type: 'separator' },
    { label: 'Открыть', click: () => { win.show(); win.focus() } },
    { type: 'separator' },
    { label: 'Выйти', click: () => { stopWinws(); app.exit(0) } }
  ]))
}

// ── Статус winws.exe ──────────────────────────────────────────────────────────
function isRunning () {
  try {
    const out = execSync('tasklist /FI "IMAGENAME eq winws.exe" /NH', {
      encoding: 'utf8', windowsHide: true, timeout: 3000
    })
    return out.toLowerCase().includes('winws.exe')
  } catch { return false }
}

// ── Запуск bat-файла с правами администратора (UAC только здесь) ─────────────
function runBatAsAdmin (filename) {
  const p = path.join(BAT_DIR, filename)
  // Используем PowerShell Start-Process -Verb RunAs → появится UAC-диалог
  return spawn('powershell.exe', [
    '-NoProfile', '-WindowStyle', 'Hidden', '-Command',
    `Start-Process cmd.exe -ArgumentList '/c ""${p}""' -Verb RunAs -WindowStyle Hidden`
  ], { windowsHide: true, shell: false })
}

// ── Остановка winws с правами администратора ─────────────────────────────────
function stopWinws () {
  try {
    // Сначала пробуем без UAC (если уже запущены как admin)
    execSync('taskkill /F /IM winws.exe', { windowsHide: true, timeout: 3000 })
    return true
  } catch {
    try {
      // Если нет прав — через PowerShell с UAC
      spawn('powershell.exe', [
        '-NoProfile', '-WindowStyle', 'Hidden', '-Command',
        'Start-Process taskkill -ArgumentList "/F /IM winws.exe" -Verb RunAs -WindowStyle Hidden'
      ], { windowsHide: true, shell: false })
      return true
    } catch { return false }
  }
}

// ── Опрос статуса ────────────────────────────────────────────────────────────
setInterval(() => {
  const s = isRunning()
  if (s !== lastStatus) {
    lastStatus = s
    updateTrayMenu()
    if (win && !win.isDestroyed()) win.webContents.send('status-changed', s)
  }
}, 2000)

// ── IPC ──────────────────────────────────────────────────────────────────────
ipcMain.handle('get-status', () => isRunning())

ipcMain.handle('run-bat', (_, filename) => {
  try {
    runBatAsAdmin(filename)
    return { ok: true }
  } catch (e) { return { ok: false, err: e.message } }
})

ipcMain.handle('stop-winws', () => {
  const ok = stopWinws()
  return { ok }
})

ipcMain.on('win-minimize', () => win?.minimize())
ipcMain.on('win-close',    () => app.exit(0))
ipcMain.on('open-url', (_, url) => shell.openExternal(url))

// ── Старт ────────────────────────────────────────────────────────────────────
app.whenReady().then(() => {
  createWindow()
  createTray()
})

app.on('window-all-closed', () => {})
