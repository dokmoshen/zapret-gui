const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('api', {
  getStatus:    ()         => ipcRenderer.invoke('get-status'),
  runBat:       (filename) => ipcRenderer.invoke('run-bat', filename),
  stopWinws:    ()         => ipcRenderer.invoke('stop-winws'),
  onStatus:     (cb)       => ipcRenderer.on('status-changed', (_, v) => cb(v)),
  winMinimize:  ()         => ipcRenderer.send('win-minimize'),
  winClose:     ()         => ipcRenderer.send('win-close'),
  openUrl:      (url)      => ipcRenderer.send('open-url', url),
})
