'use strict'

// ── Данные режимов ────────────────────────────────────────────────────────────
const MODES = [
  { name: 'general',             file: 'general.bat',                      desc: 'Стандартный режим. Рекомендуется попробовать первым.' },
  { name: 'ALT',                 file: 'general (ALT).bat',                desc: 'Альтернативный метод 1. Попробуй если general не помог.' },
  { name: 'ALT 2',               file: 'general (ALT2).bat',               desc: 'Альтернативный метод 2.' },
  { name: 'ALT 3',               file: 'general (ALT3).bat',               desc: 'Альтернативный метод 3.' },
  { name: 'ALT 4',               file: 'general (ALT4).bat',               desc: 'Альтернативный метод 4.' },
  { name: 'ALT 5',               file: 'general (ALT5).bat',               desc: 'Альтернативный метод 5.' },
  { name: 'ALT 6',               file: 'general (ALT6).bat',               desc: 'Альтернативный метод 6.' },
  { name: 'ALT 7',               file: 'general (ALT7).bat',               desc: 'Альтернативный метод 7.' },
  { name: 'ALT 8',               file: 'general (ALT8).bat',               desc: 'Альтернативный метод 8.' },
  { name: 'ALT 9',               file: 'general (ALT9).bat',               desc: 'Альтернативный метод 9.' },
  { name: 'ALT 10',              file: 'general (ALT10).bat',              desc: 'Альтернативный метод 10.' },
  { name: 'ALT 11',              file: 'general (ALT11).bat',              desc: 'Альтернативный метод 11. Самый агрессивный из ALT.' },
  { name: 'FAKE TLS AUTO',       file: 'general (FAKE TLS AUTO).bat',      desc: 'Авто Fake TLS. Хорошо работает на многих провайдерах.' },
  { name: 'FAKE TLS AUTO ALT',   file: 'general (FAKE TLS AUTO ALT).bat',  desc: 'Fake TLS AUTO — альтернативный вариант 1.' },
  { name: 'FAKE TLS AUTO ALT 2', file: 'general (FAKE TLS AUTO ALT2).bat', desc: 'Fake TLS AUTO — альтернативный вариант 2.' },
  { name: 'FAKE TLS AUTO ALT 3', file: 'general (FAKE TLS AUTO ALT3).bat', desc: 'Fake TLS AUTO — альтернативный вариант 3.' },
  { name: 'SIMPLE FAKE',         file: 'general (SIMPLE FAKE).bat',        desc: 'Простой Fake-режим. Лёгкий и быстрый.' },
  { name: 'SIMPLE FAKE ALT',     file: 'general (SIMPLE FAKE ALT).bat',    desc: 'Простой Fake — альтернативный вариант 1.' },
  { name: 'SIMPLE FAKE ALT 2',   file: 'general (SIMPLE FAKE ALT2).bat',   desc: 'Простой Fake — альтернативный вариант 2.' },
]

// ── Состояние ─────────────────────────────────────────────────────────────────
let selectedIndex = 0
let isRunning     = false
let snackTimer    = null

// ── DOM ───────────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id)

const statusDot   = $('status-dot')
const statusLabel = $('status-label')
const btnToggle   = $('btn-toggle')
const selectTrig  = $('select-trigger')
const selectVal   = $('select-value')
const menu        = $('md-menu')
const modeDesc    = $('mode-desc')
const logBody     = $('log-body')
const snackbar    = $('snackbar')
const snackText   = $('snackbar-text')

// ── Навигация ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'))
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'))
    item.classList.add('active')
    $(`page-${item.dataset.page}`).classList.add('active')
  })
})

// ── Title bar ─────────────────────────────────────────────────────────────────
$('btn-min').addEventListener('click',   () => window.api.winMinimize())
$('btn-close').addEventListener('click', () => window.api.winClose())

// ── Custom Select ─────────────────────────────────────────────────────────────
MODES.forEach((m, i) => {
  const el = document.createElement('div')
  el.className = 'md-menu-item' + (i === 0 ? ' selected' : '')
  el.textContent = m.name
  el.dataset.index = i
  el.addEventListener('click', e => {
    e.stopPropagation()
    setMode(i)
    closeMenu()
  })
  menu.appendChild(el)
})

selectTrig.addEventListener('click', e => {
  e.stopPropagation()
  toggleMenu()
})

document.addEventListener('click', () => closeMenu())

function toggleMenu () {
  const open = menu.classList.toggle('open')
  selectTrig.classList.toggle('open', open)
}
function closeMenu () {
  menu.classList.remove('open')
  selectTrig.classList.remove('open')
}
function setMode (i) {
  selectedIndex = i
  selectVal.textContent = MODES[i].name
  animateDesc(MODES[i].desc)
  document.querySelectorAll('.md-menu-item').forEach(el => {
    el.classList.toggle('selected', +el.dataset.index === i)
  })
}

// animateDesc объявлен ниже, но JS-функции hoisted, поэтому порядок OK

setMode(0)

// ── Статус ────────────────────────────────────────────────────────────────────
function applyStatus (running) {
  isRunning = running
  statusDot.classList.toggle('running', running)
  statusLabel.classList.toggle('running', running)
  statusLabel.classList.toggle('stopped', !running)
  statusLabel.textContent = running ? 'Запущен — winws.exe работает' : 'Остановлен'
  btnToggle.classList.toggle('on', running)
  btnToggle.setAttribute('aria-pressed', running ? 'true' : 'false')
  btnToggle.disabled = false
}

window.api.onStatus(v => applyStatus(v))

window.api.getStatus().then(v => applyStatus(v))

// ── Кнопка-переключатель (Android 16 style) ──────────────────────────────────
btnToggle.addEventListener('click', async () => {
  if (btnToggle.disabled) return
  btnToggle.disabled = true

  if (!isRunning) {
    // ЗАПУСК
    const mode = MODES[selectedIndex]
    addLog(`Запуск режима "${mode.name}"…`, 'primary')

    const res = await window.api.runBat(mode.file)
    if (!res.ok) {
      addLog(`Ошибка: ${res.err}`, 'error')
      toast('Ошибка запуска!')
      btnToggle.disabled = false
      return
    }

    setTimeout(async () => {
      const running = await window.api.getStatus()
      applyStatus(running)
      if (running) {
        addLog('Успешно запущен!', 'success')
        toast('Запущен')
      } else {
        addLog('Запущен, ожидание инициализации…', 'info')
        toast('Запуск…')
      }
    }, 2000)
  } else {
    // ОСТАНОВКА
    addLog('Остановка winws.exe…', 'info')
    await window.api.stopWinws()

    setTimeout(async () => {
      const running = await window.api.getStatus()
      applyStatus(running)
      if (!running) {
        addLog('Остановлен.', 'success')
        toast('Остановлен')
      } else {
        addLog('Не удалось остановить.', 'error')
        toast('Ошибка остановки')
      }
    }, 900)
  }
})

// ── Очистка лога ──────────────────────────────────────────────────────────────
$('btn-clear').addEventListener('click', () => {
  logBody.innerHTML = ''
  addLog('Лог очищен.', 'info')
})

// ── GitHub ────────────────────────────────────────────────────────────────────
$('link-github').addEventListener('click', () => {
  window.api.openUrl('https://github.com/Flowseal/zapret-discord-youtube')
})

// ── Лог ──────────────────────────────────────────────────────────────────────
function addLog (msg, type = 'info') {
  const time  = new Date().toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  const entry = document.createElement('div')
  entry.className = 'log-entry'
  entry.innerHTML = `<span class="log-time">${time}</span><span class="log-msg ${type}">${escHtml(msg)}</span>`
  logBody.appendChild(entry)
  logBody.scrollTop = logBody.scrollHeight
}

// ── Snackbar ──────────────────────────────────────────────────────────────────
function toast (msg, ms = 2800) {
  snackText.textContent = msg
  snackbar.classList.add('show')
  clearTimeout(snackTimer)
  snackTimer = setTimeout(() => snackbar.classList.remove('show'), ms)
}

// ── Utils ─────────────────────────────────────────────────────────────────────
function escHtml (str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
}

// ── Ripple эффект на всех кнопках ────────────────────────────────────────────
document.querySelectorAll('.md-btn, .md-toggle-btn').forEach(btn => {
  btn.addEventListener('pointerdown', e => {
    const r   = btn.getBoundingClientRect()
    const size = Math.max(r.width, r.height) * 2
    const x  = e.clientX - r.left - size / 2
    const y  = e.clientY - r.top  - size / 2
    const rp = document.createElement('span')
    rp.className = 'ripple'
    rp.style.cssText = `width:${size}px;height:${size}px;left:${x}px;top:${y}px`
    btn.appendChild(rp)
    rp.addEventListener('animationend', () => rp.remove())
  })
})

// ── Анимация смены описания режима ───────────────────────────────────────────
function animateDesc (text) {
  modeDesc.classList.add('changing')
  setTimeout(() => {
    modeDesc.textContent = text
    modeDesc.classList.remove('changing')
  }, 100)
}

// ══════════════════════════════════════════════════════════════
// НАСТРОЙКИ — тема и палитра
// ══════════════════════════════════════════════════════════════

const html = document.documentElement

// Применить тему с анимацией перехода
function applyTheme (theme, palette, save = true) {
  // Включаем CSS-переход цветов
  html.classList.add('theme-transition')

  html.dataset.theme   = theme
  html.dataset.palette = palette

  // Убираем класс после завершения перехода
  setTimeout(() => html.classList.remove('theme-transition'), 400)

  // Синхронизируем M3 switch
  const themeSwitch = $('theme-switch')
  const themeLabel  = $('theme-row-label')
  if (themeSwitch) {
    const isLight = theme === 'light'
    themeSwitch.setAttribute('aria-checked', isLight ? 'true' : 'false')
    if (themeLabel) themeLabel.textContent = isLight ? 'Светлая тема' : 'Тёмная тема'
  }

  document.querySelectorAll('#palette-group .palette-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.value === palette)
  })

  if (save) {
    localStorage.setItem('zap-theme',   theme)
    localStorage.setItem('zap-palette', palette)
  }
}

// Загрузка сохранённых настроек
const savedTheme   = localStorage.getItem('zap-theme')   || 'dark'
const savedPalette = localStorage.getItem('zap-palette') || 'purple'
applyTheme(savedTheme, savedPalette, false)

// Переключение темы — Android 16 M3 Switch
const themeSwitchEl = $('theme-switch')
if (themeSwitchEl) {
  themeSwitchEl.addEventListener('click', () => {
    const isLight = themeSwitchEl.getAttribute('aria-checked') === 'true'
    const next    = isLight ? 'dark' : 'light'
    applyTheme(next, html.dataset.palette)
    toast(next === 'dark' ? 'Тёмная тема' : 'Светлая тема')
  })
}

// Выбор палитры
document.querySelectorAll('#palette-group .palette-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    applyTheme(html.dataset.theme, btn.dataset.value)
    const names = {
      purple: 'Фиолетовый', blue: 'Синий', green: 'Зелёный',
      red: 'Красный', teal: 'Бирюзовый', orange: 'Оранжевый'
    }
    toast(`Палитра: ${names[btn.dataset.value] || btn.dataset.value}`)
  })
})

// Ripple на seg-btn и palette-btn
document.querySelectorAll('.seg-btn, .palette-btn').forEach(btn => {
  btn.addEventListener('pointerdown', e => {
    const r    = btn.getBoundingClientRect()
    const size = Math.max(r.width, r.height) * 2
    const rp   = document.createElement('span')
    rp.className = 'ripple'
    rp.style.cssText =
      `width:${size}px;height:${size}px;` +
      `left:${e.clientX - r.left - size/2}px;` +
      `top:${e.clientY - r.top  - size/2}px`
    btn.appendChild(rp)
    rp.addEventListener('animationend', () => rp.remove())
  })
})

// ── Старт ─────────────────────────────────────────────────────────────────────
addLog('Приложение запущено. Выбери режим и нажми Запустить.', 'primary')
